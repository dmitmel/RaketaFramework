package github.dmitmel.raketaframework.tests.util;

import github.dmitmel.raketaframework.web.HTTPRequest;
import github.dmitmel.raketaframework.web.URL;
import org.junit.Assert;
import org.junit.Test;

import java.util.HashMap;

public class StringsFromHttpRequestsTest extends Assert {
    public static final String TESTING_MESSAGE_BODY = "Some text.";

    @Test
    public void testNothing() {
        HTTPRequest message = new HTTPRequest("GET", new URL("/"), "HTTP/1.1");

        String expected = "GET / HTTP/1.1\r\n" +
                "\r\n";
        assertEquals(expected, message.toString());
    }

    @Test
    public void testHeadersAndBody() {
        HashMap<String, String> headers = new HashMap<>(2);
        headers.put("A", "B");
        headers.put("C", "D");
        HTTPRequest message = new HTTPRequest("GET", new URL("/"), "HTTP/1.1", headers, TESTING_MESSAGE_BODY.getBytes());

        String expected = "GET / HTTP/1.1\r\n" +
                "A: B\r\n" +
                "C: D\r\n" +
                "\r\n" +
                TESTING_MESSAGE_BODY;
        assertEquals(expected, message.toString());
    }

    @Test
    public void testHeaders() {
        HashMap<String, String> headers = new HashMap<>(2);
        headers.put("A", "B");
        headers.put("C", "D");
        HTTPRequest message = new HTTPRequest("GET", new URL("/"), "HTTP/1.1", headers, new byte[0]);

        String expected = "GET / HTTP/1.1\r\n" +
                "A: B\r\n" +
                "C: D\r\n" +
                "\r\n";
        assertEquals(expected, message.toString());
    }

    @Test
    public void testBody() {
        HTTPRequest message = new HTTPRequest("GET", new URL("/"), "HTTP/1.1", TESTING_MESSAGE_BODY.getBytes());

        String expected = "GET / HTTP/1.1\r\n" +
                "\r\n" +
                TESTING_MESSAGE_BODY;
        assertEquals(expected, message.toString());
    }
}
