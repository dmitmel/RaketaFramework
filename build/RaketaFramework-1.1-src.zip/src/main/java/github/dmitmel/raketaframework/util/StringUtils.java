package github.dmitmel.raketaframework.util;

import github.dmitmel.raketaframework.web.errors.Error501;

public class StringUtils {
    public static final String EMPTY_STRING = "";
}
