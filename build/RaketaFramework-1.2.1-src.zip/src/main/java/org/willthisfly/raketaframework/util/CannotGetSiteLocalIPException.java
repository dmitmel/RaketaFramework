package org.willthisfly.raketaframework.util;

import org.willthisfly.raketaframework.exceptions.SocketException;

public class CannotGetSiteLocalIPException extends SocketException {
    public CannotGetSiteLocalIPException() {
        super();
    }
}
