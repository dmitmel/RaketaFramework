package github.dmitmel.raketaframework.util;

public class InvalidMethodSignatureException extends RuntimeException {
    public InvalidMethodSignatureException(String s) {
        super(s);
    }
}
