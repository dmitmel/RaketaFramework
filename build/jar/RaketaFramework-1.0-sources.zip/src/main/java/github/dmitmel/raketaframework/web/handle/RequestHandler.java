package github.dmitmel.raketaframework.web.handle;

/**
 * Marker-interface for request handlers.
 */
public interface RequestHandler {
}
