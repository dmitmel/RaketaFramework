package github.dmitmel.raketaframework.util;

import github.dmitmel.raketaframework.util.exceptions.SocketException;

public class CurrentIpCannotBeFoundException extends SocketException {
    public CurrentIpCannotBeFoundException() {
        super();
    }
}
