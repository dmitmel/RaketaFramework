package github.dmitmel.raketaframework.util;

public class StringUtils {
    public static final String EMPTY_STRING = "";
}
