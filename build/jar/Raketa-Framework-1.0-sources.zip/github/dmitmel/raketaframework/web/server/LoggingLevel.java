package github.dmitmel.raketaframework.web.server;

public enum LoggingLevel {
    REQUEST_SUMMARY, CLIENT_ACCEPTING_START, CLIENT_ACCEPTING_END, EXCEPTION, START_CONFIG, INFO, FATAL_ERROR
}
