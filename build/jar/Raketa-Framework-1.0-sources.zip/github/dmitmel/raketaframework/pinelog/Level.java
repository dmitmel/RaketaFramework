package github.dmitmel.raketaframework.pinelog;

public enum Level {
    INFO, DEBUG, WARNING, ERROR, FATAL, EXCEPTION
}
