package github.dmitmel.raketaframework.util;

import github.dmitmel.raketaframework.exceptions.SocketException;

public class CannotGetSiteLocalIPException extends SocketException {
    public CannotGetSiteLocalIPException() {
        super();
    }
}
